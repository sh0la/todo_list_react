import React from 'react';

function DoneItem() {
    return (
      <ul>
        <li>This is a Done Item</li>
      </ul>
    )
}

export default DoneItem;