import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import UserInput from './UserInput';
import Listing from './components/Listing'


class Page extends Component {
  constructor(props) {
    super(props);
  }
  
  render() {
    console.log(this.props)
    return(
      <div>
        <UserInput />
        <Listing />
      </div>
    )
  }
}

ReactDOM.render(<Page />, document.getElementById('root'));


